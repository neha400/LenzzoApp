package com.lenzzo.interfacelenzzo;

import android.app.Dialog;

public interface UserCartInterface {
    public void getUserCartValue(Dialog dialog);
}
