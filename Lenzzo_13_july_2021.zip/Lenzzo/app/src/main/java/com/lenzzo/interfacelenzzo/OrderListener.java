package com.lenzzo.interfacelenzzo;

import com.lenzzo.model.MyOrderModel;

public interface OrderListener {

    void onReorder(MyOrderModel myOrder);
}
