package com.lenzzo.interfacelenzzo;

import org.json.JSONArray;

public interface FilterListChildInterface {
    public void getFilterChildId(String id, boolean check_uncheck, JSONArray jsonArray,String slug);
}
