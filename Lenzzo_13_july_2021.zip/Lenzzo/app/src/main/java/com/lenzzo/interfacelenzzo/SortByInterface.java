package com.lenzzo.interfacelenzzo;

public interface SortByInterface {
    public void sortByPrice(String key,String value);
}
