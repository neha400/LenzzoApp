package com.lenzzo.interfacelenzzo;

public interface RefreshProductList {

    void refreshList();
}
