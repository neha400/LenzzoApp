package com.lenzzo.interfacelenzzo;

public interface UserAddressInterface {
    public void getAddressId(String addressId,String name,String area,String block,String street,String avenue,String house,String floor,String flat,String phone,String comments);
}
