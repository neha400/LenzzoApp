package com.lenzzo.interfacelenzzo;

public interface GiftInterface {
    public void getGiftId(String giftId);
}
