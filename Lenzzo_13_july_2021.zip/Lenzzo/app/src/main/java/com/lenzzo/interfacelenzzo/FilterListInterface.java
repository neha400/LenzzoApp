package com.lenzzo.interfacelenzzo;

import org.json.JSONArray;

public interface FilterListInterface {
    public void listOfName(JSONArray jsonArray,String title);
}
