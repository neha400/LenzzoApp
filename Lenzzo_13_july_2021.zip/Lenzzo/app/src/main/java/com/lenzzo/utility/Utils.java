package com.lenzzo.utility;

import java.util.HashMap;
import java.util.Map;

public class Utils {
    public static final String regEx = "\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}\\b";

    public static final String PREF_NAME = "lenzzouser";
    public static final String FILTER_NAME = "lenzzofilter";
    public static final String KENT_TEST_KEY = "Bearer sk_test_XKokBfNWv6FIYuTMg5sLPjhJ";
   // public static final String KENT_LIVE_KEY = "Bearer sk_live_srmq974IH51KQEYABvhCwMoF";


}
