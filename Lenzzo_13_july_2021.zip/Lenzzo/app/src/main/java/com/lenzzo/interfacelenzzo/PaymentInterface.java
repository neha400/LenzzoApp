package com.lenzzo.interfacelenzzo;

public interface PaymentInterface {
    public void paymentMode(String paymentModeid,String payment_name);
}
